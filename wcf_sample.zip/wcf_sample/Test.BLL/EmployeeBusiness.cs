﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.DAL;
using Test.Model;

namespace Test.BLL
{
	public class EmployeeBusiness
	{
		private readonly IDataProvider dal;
		public EmployeeBusiness()
		{
			dal = DataAccess.CreateInstance<IDataProvider>("DataProvider");
		}

		public Response InsertData(EmployeeModel employeeModel)
		{
			return dal.InsertData(employeeModel);
		}
	}
}
