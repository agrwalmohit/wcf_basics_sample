﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;

namespace Test.Services.ExceptionHandler
{
	public class GlobalErrorHandler : IErrorHandler
	{
		public bool HandleError(Exception error)
		{
			return true;
		}

		public void ProvideFault(Exception error, MessageVersion version, ref Message fault)
		{
			if (error is FaultException)
				return;

			var faultException = new FaultException($"Exception caught at service Method: { error.TargetSite.Name}  and Message: {error.Message}");
			var messageFault = faultException.CreateMessageFault();
			fault = Message.CreateMessage(version, messageFault, faultException.Action);
		}
	}
}