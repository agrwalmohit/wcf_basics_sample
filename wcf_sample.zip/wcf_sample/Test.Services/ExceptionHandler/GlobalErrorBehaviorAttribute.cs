﻿using System;
using System.Collections.ObjectModel;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

namespace Test.Services.ExceptionHandler
{
	public class GlobalErrorBehaviorAttribute : Attribute, IServiceBehavior
	{
		private readonly Type _errorHanderType;
		public GlobalErrorBehaviorAttribute(Type errorHandlerType)
		{
			this._errorHanderType = errorHandlerType;
		}

		#region ****** IServiceBehaviour ******		
		/// <summary>
		/// Don't implement
		/// </summary>
		/// <param name="serviceDescription"></param>
		/// <param name="serviceHostBase"></param>
		/// <param name="endpoints"></param>
		/// <param name="bindingParameters"></param>
		public void AddBindingParameters(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase, Collection<ServiceEndpoint> endpoints, BindingParameterCollection bindingParameters)
		{
		}

		public void ApplyDispatchBehavior(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
		{
			IErrorHandler errorHandler;
			try
			{
				errorHandler = (IErrorHandler)Activator.CreateInstance(_errorHanderType);
				foreach (ChannelDispatcherBase channelDispacherBase in serviceHostBase.ChannelDispatchers)
				{
					ChannelDispatcher channelDispatcher = channelDispacherBase as ChannelDispatcher;
					if (channelDispatcher != null)
						channelDispatcher.ErrorHandlers.Add(errorHandler);
				}
			}
			catch (MissingMethodException ex)
			{
				throw new ArgumentException(@"The errorHandlerType specified in the ErrorBehaviorAttribute 
				constructor must have a public empty constructor.", ex);
			}
			catch (InvalidCastException ex)
			{
				throw new ArgumentException(@"The errorHandlerType specified in the ErrorBehaviorAttribute constructor
				must implement System.ServiceModel.Dispatcher.IErrorHandler.", ex);
			}
			catch (Exception ex)
			{
			}


		}

		/// <summary>Don't implement
		/// </summary>
		/// <param name="serviceDescription"></param>
		/// <param name="serviceHostBase"></param>
		public void Validate(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
		{
		}
		#endregion
	}
}