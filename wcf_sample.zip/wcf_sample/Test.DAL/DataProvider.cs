﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Test.Model;

namespace Test.DAL
{
	public class DataProvider : IDataProvider
	{
		public Response InsertData(EmployeeModel employeeModel)
		{
			Response response = new Response();
			try
			{
				using (SqlConnection connection = new SqlConnection(GetConnectionString))
				{
					SqlCommand cmd = new SqlCommand("");
					cmd.CommandType = System.Data.CommandType.StoredProcedure;
					connection.Open();
					int result = cmd.ExecuteNonQuery();
					connection.Close();

					if (result > 0)
					{
						response.Result = "Success";
						response.Message = "data insert successfully";
					}
				}
			}
			catch (SqlException sqlEx)
			{
				response.Result = "Failed";
				response.Message = "Connection can not open this " +
				   "time either connection string is wrong or Sever is down. Try later";
				response.Details = sqlEx.ToString();
				//throw new FaultException<response>(response, sqlEx.ToString());
			}
			catch (Exception ex)
			{
				response.Result = "Failed";
				response.Message = "unforeseen error occurred. Please try later.";
				response.Details = ex.ToString();
				//throw new FaultException<response>(response, ex.ToString());
			}
			return response;
		}

		public static string GetConnectionString
		{
			get { return ConfigurationManager.ConnectionStrings["ConnectionString"].ToString(); }
		}
	}

	public class DataAccess
	{
		private static readonly string path = ConfigurationManager.AppSettings["Test.DAL"];
		public static T CreateInstance<T>(string classPath)
		{
			string className = string.Format("{0}.{1}", path, classPath);
			return (T)Assembly.Load(path).CreateInstance(className);
		}
	}
}
